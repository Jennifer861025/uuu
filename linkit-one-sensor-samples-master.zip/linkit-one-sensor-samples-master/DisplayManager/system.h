/* GLOBAL CONFIGURATION FILE FOR SYSTEM SETTINGS. */

//Default system display.
//Options:  
//          disp_OLED_128x64
//          disp_OLED_96x96
#define CONFIG_SYSTEM_DEFAULT_DISPLAY disp_OLED_128x64
